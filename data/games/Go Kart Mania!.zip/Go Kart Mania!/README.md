Controls:

Use W to accelerate, S to brake/reverse, A and D to steer

I lost the source to this game back in 2012, so I could not finish it, and it doesn't have a timer. A white cube acts as a starting/ending position for the lap.